<?php
require '../ACCIONES/FUNCIONES/conexion.php';


$query = "SELECT * FROM `productos` WHERE user_id = $id";
$result = ejecutar($query);
while ($row = $result ->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row["prod_id"] . "</td>";
    echo "<td>" . $row["nombre"] . "</td>";
    echo "<td>" . $row["descripcion"] . "</td>";
    echo "<td>" . $row["precio"] . "</td>";
    echo "<td>" . $row["cantidad_stock"] . "</td>";
    echo "</tr>";
}
while ($row = $result ->fetch_assoc()) {
    echo "<div id='respuesta'>"."ID: " . $row["prod_id"] . "<br>";
    echo "Nombre: " . $row["nombre"] . "<br>";
    echo "Descripcion: " . $row["descripcion"] . "<br>";
    echo "Precio: " . $row["precio"] . "<br>";
    echo "Cantidad: " . $row["cantidad_stock"] . "<br>";
    echo "<hr></div>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["EditarProductos"])) {

        header("Location: ./Nivel3/actproductos.php");
        exit();

    } else {
        //Previene de errores no previstos
        echo "Comando no válido";
    }
}




?>