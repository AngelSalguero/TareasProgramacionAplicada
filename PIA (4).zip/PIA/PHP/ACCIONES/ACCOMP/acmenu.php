<?php
require '../ACCIONES/FUNCIONES/conexion.php';

session_start();
$id = $_SESSION['id'];
$query = "SELECT nombre FROM usuarios WHERE user_id = '$id'";
$result = ejecutar($query);
while ($row = $result ->fetch_assoc()) {
    $Nombre = $row["nombre"];
}
echo '<h3 class="respuesta"> Bienvenido, ' . $Nombre. '</h3>';

// Verifica si se han enviado datos a través del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["Perfil"])) {

        header("Location: ./perfil.php");
        exit();
        
    } elseif (isset($_POST["Producto"])) {

        header("Location: ./productos.php");
        exit();

    } elseif (isset($_POST["Transacciones"])) {

        header("Location: ./transacciones.php");
        exit();

    } elseif (isset($_POST["Facturas"])) {

        header("Location: ./facturas.php");
        exit();
        
    } elseif (isset($_POST["MetodosDePago"])) {

        header("Location: ./metodos.php");
        exit();

    } elseif (isset($_POST["Informes"])) {

        header("Location: ./informes.php");
        exit();

    } elseif (isset($_POST["Clientes"])) {

        header("Location: ./clientes.php");
        exit();

    } elseif (isset($_POST["CerrarSesion"])) {

        session_start();
        session_destroy();
        header("Location: ../login.php");
        exit();

    } else {
        
        //Previene de errores no previstos
        echo "Comando no valido";
    
    }

}


?>