<?php
require '../ACCIONES/FUNCIONES/conexion.php';


$query = "SELECT * FROM `clientes` WHERE user_id = $id";
$result = ejecutar($query);
while ($row = $result ->fetch_assoc()) {

    echo "<tr>";
    echo "<td>" . $row["cliente_id"] . "</td>";
    echo "<td>" . $row["nombre"] . "</td>";
    echo "<td>" . $row["apellido"] . "</td>";
    echo "<td>" . $row["correo"] . "</td>";
    echo "<td>" . $row["telefono"] . "</td>";
    echo "</tr>";

}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["EditarClientes"])) {

        header("Location: ./Nivel3/actclientes.php");
        exit();

    } else {
        //Previene de errores no previstos
        echo "Comando no válido";
    }
}




?>