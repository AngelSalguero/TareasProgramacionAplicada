<?php
require '../ACCIONES/FUNCIONES/conexion.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["MostrarFacturas"])) {

        header("Location: ./Nivel3/mostrarfactura.php");
        exit();

    } elseif (isset($_POST["AgregarFacturas"])) {
        header("Location: ./Nivel3/crearfactura.php");
        exit();
    } else {
        //Previene de errores no previstos
        echo "Comando no válido";
    }
}




?>