<?php
require '../ACCIONES/FUNCIONES/conexion.php';


$query = "SELECT * FROM `metodopago` WHERE `user_id`=$id";
$result = ejecutar($query);
while ($row = $result ->fetch_assoc()) {

    echo "<tr>";
    echo "<td>" . $row["met_id"] . "</td>";
    echo "<td>" . $row["nombre"] . "</td>";
    echo "</tr>";

}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["EditarMetodos"])) {

        header("Location: ./Nivel3/actmetodos.php");
        exit();

    } else {
        //Previene de errores no previstos
        echo "Comando no válido";
    }
}




?>