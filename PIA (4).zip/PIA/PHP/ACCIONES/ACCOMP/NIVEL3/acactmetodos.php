<?php
 // Hace posible la ejecucion de las funciones, de tal manera que no tenga que ponerla en cada archivo
require '../../ACCIONES/FUNCIONES/conexion.php';
session_start();
$id = $_SESSION['id'];
// Verifica si se han enviado datos a través del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

        // Obtén los datos del formulario
        $id_prod = $_POST["input1"];
        $nombre = $_POST["input2"];

    if (isset($_POST["Traer"])) {

        if ($id_prod == "") {
            echo "<div id='respuesta'> Ingrese un id <hr></div>";
        } else {
            $query = "SELECT * FROM `metodopago` WHERE met_id = $id_prod";
            $result = ejecutar($query);
            try {
                if ($result->num_rows == 0) {
                    echo "<div id='respuesta'>El id no existe en la base de datos</div>";
                } elseif ($result) {
                    while ($row = $result ->fetch_assoc()) {
                    echo "<div id='respuesta'>"."ID: " . $row["met_id"] . "<br>";
                    echo "Nombre: " . $row["nombre"] . "<br>";
                    echo "<hr></div>";
                    }
                } else {
                    echo "<div id='respuesta'>Error en la consulta: </div>" . $connection->error;
                }
            
            } catch (mysqli_sql_exception $e) {
                // Captura el error y muestra un mensaje personalizado
                echo "<div id='respuesta'>Error en la consulta: </div>" . $e->getMessage();
            }
        }

    } elseif (isset($_POST["Actualizar"])) {

        if ($id_prod == "") {
            echo "<div id='respuesta'> Ingrese un id <hr></div>";
        } else {
            $query = "UPDATE `metodopago` SET `nombre`='$nombre' WHERE met_id = $id_prod";
            $result = ejecutar($query);
            try {
                if ($result === TRUE) {
                    echo "<div id='respuesta'>Registro actualizado con éxito.</div>";
                } else {
                    echo "<div id='respuesta'>Error al actualizar el registro: " . $connection->error . "</div>";
                }
            
            } catch (mysqli_sql_exception $e) {
                // Captura el error y muestra un mensaje personalizado
                echo "<div id='respuesta'>Error en la consulta: </div>" . $e->getMessage();
            }
        }

    }elseif (isset($_POST["Insertar"])) {

        if ($id_prod == "") {
            echo "<div id='respuesta'> Ingrese un id <hr></div>";
        } else {

            $query = "SELECT * FROM `metodopago` WHERE met_id = $id_prod";
            $result = ejecutar($query);
            try {
                if ($result->num_rows == 0) {
                    $query = "INSERT INTO `metodopago`(`nombre`) VALUES ('$nombre')";
                    $result = ejecutar($query);
                    try {
                        if ($result === TRUE) {
                            echo "<div id='respuesta'>Registro insertado con éxito.</div>";
                        } else {
                            echo "<div id='respuesta'>Error al insertar el registro: " . $connection->error . "</div>";
                        }
                    
                    } catch (mysqli_sql_exception $e) {
                        // Captura el error y muestra un mensaje personalizado
                        echo "<div id='respuesta'>Error en la consulta: </div>" . $e->getMessage();
                    }
                } elseif ($result) {
                    echo "El id del metodo ya existe";
                } else {
                echo "<div id='respuesta'>Error en la consulta: </div>" . $connection->error;
                }
            
            } catch (mysqli_sql_exception $e) {
                // Captura el error y muestra un mensaje personalizado
                echo "<div id='respuesta'>Error en la consulta: </div>" . $e->getMessage();
            }

        }

    }elseif (isset($_POST["Borrar"])) {

        if ($id_prod == "") {
            echo "<div id='respuesta'> Ingrese un id <hr></div>";
        } else {
            $query = "SELECT * FROM `metodopago` WHERE met_id = $id_prod";
            $result = ejecutar($query);
            try {
                if ($result->num_rows == 0) {
                    echo "<div id='respuesta'>El id no existe en la base de datos</div>";
                } elseif ($result) {
                    $query = "DELETE FROM `metodopago` WHERE met_id = $id_prod";
                    $result = ejecutar($query);
                    if ($result === TRUE) {
                        echo "<div id='respuesta'>Registro eliminado con éxito.</div>";
                    } else {
                        echo "<div id='respuesta'>Error al eliminar el registro: " . $connection->error . "</div>";
                    }
                } else {
                echo "<div id='respuesta'>Error en la consulta: </div>" . $connection->error;
                }
            
            } catch (mysqli_sql_exception $e) {
                // Captura el error y muestra un mensaje personalizado
                echo "<div id='respuesta'>Error en la consulta: </div>" . $e->getMessage();
            }
        }

    }elseif (isset($_POST["Volver"])) {

        header("Location: ../metodos.php");
        exit();

    } else {
        
        //Previene de errores no previstos
        echo "Comando no valido";
    
    }

}


?>