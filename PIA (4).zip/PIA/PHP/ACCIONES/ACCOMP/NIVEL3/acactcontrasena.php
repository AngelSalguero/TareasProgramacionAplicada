<?php
 // Hace posible la ejecucion de las funciones, de tal manera que no tenga que ponerla en cada archivo
require '../../ACCIONES/FUNCIONES/conexion.php';
session_start();
$id = $_SESSION['id'];
// Verifica si se han enviado datos a través del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["Actualizar"])) {

        // Obtén los datos del formulario
        $contrasena = $_POST["input6"];

        if ($contrasena == "") {
                //Previene del error de 0 ya existe
                echo "<div id='respuesta'> Cambie el correo </div>";
        } else {
            
                $sql = "UPDATE `usuarios` SET `contrasena`='$contrasena' WHERE `user_id`=$id";
                try {
                    //Crea una variable result que es el resultado de la insercion
                    $result = ejecutar($sql);
                    if ($result === TRUE) {
                        echo "<div id='respuesta'>Registro actualizado con éxito.</div>";
                    } else {
                        echo "<div id='respuesta'>Error al actualizar el registro: </div>" . $connection->error;
                        echo "<hr>";
                    }
                } catch (mysqli_sql_exception $e) {
                    // Captura el error y muestra un mensaje personalizado
                    echo "<div id='respuesta'>Error en la consulta: </div>" . $e->getMessage();
                }
            
                
                    
        }

    } elseif (isset($_POST["Volver"])) {

        header("Location: ../perfil.php");
        exit();

    } else {
        
        //Previene de errores no previstos
        echo "Comando no valido";
    
    }

}


?>