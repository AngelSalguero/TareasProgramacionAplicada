<?php
require '../../FUNCIONES/conexion.php';
session_start();
$id = $_SESSION['id'];
$data = $_GET; // Cambiar a $_GET
$query = "SELECT * FROM `metodopago` WHERE user_id = $id";
$result = ejecutar($query);

// Construir opciones HTML
$options = '';
while ($row = $result->fetch_assoc()) {
    $cliente_id = $row["met_id"];
    $nombre = $row["nombre"];
    $options .= '<option value="' . $cliente_id . '">' . $nombre . '</option>';
}

// Imprimir opciones
echo $options;
?>