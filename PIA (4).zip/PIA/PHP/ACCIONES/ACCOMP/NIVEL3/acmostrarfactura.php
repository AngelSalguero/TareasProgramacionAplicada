<?php
            require '../../ACCIONES/FUNCIONES/conexion.php';

            $id = $_SESSION['id'];
            $_SESSION['idFact'] = null;
            $data = $_POST;
            
            // Verificar directamente qué botón fue presionado en el formulario
            if (isset($_POST["MostrarFacturas"])) {

                $cliente = $_POST["cliente"];
                $fact_id = $_POST['factura'];
            
                // Consulta para obtener información del cliente
                $queryCliente = "SELECT * FROM `clientes` WHERE cliente_id = $cliente";
                $resultCliente = ejecutar($queryCliente);
            
                if ($resultCliente && $rowCliente = $resultCliente->fetch_assoc()) {
                    $cliente_id = $rowCliente["cliente_id"];
                    $cliente_nombre = $rowCliente["nombre"];
                    $cliente_apellido = $rowCliente["apellido"];
                    $cliente_correo = $rowCliente["correo"];
                    $cliente_telefono = $rowCliente["telefono"];
            
                    // Presentación de la información del cliente
                    echo "<h4>CLIENTE</h4>";
                    echo "<table>";
                    echo "<tr><th>Id</th><th>Nombre</th><th>Apellido</th><th>Correo</th><th>Teléfono</th></tr>";
                    echo "<tr><td>$cliente_id</td><td>$cliente_nombre</td><td>$cliente_apellido</td><td>$cliente_correo</td><td>$cliente_telefono</td></tr>";
                    echo "</table>";
                }
            
                // Consulta para obtener información de la factura
                $queryFactura = "SELECT 
                    facturas.fact_id AS factura_id,
                    facturas.fechaEmision AS factura_fechaEmision, 
                    facturas.total AS factura_total, 
                    facturas.tipo AS factura_tipo, 
                    clientes.nombre AS cliente_nombre,
                    clientes.apellido AS cliente_apellido,
                    clientes.correo AS cliente_correo,
                    clientes.telefono AS cliente_telefono,
                    productos.nombre AS producto_nombre,
                    productos.descripcion AS producto_descripcion,
                    productos.precio AS producto_precio,
                    detallefacturas.cantidad AS detalle_cantidad,
                    detallefacturas.det_id AS detalle_id,
                    metodopago.nombre AS pago_nombre,
                    metodofactura.monto AS metodo_monto,
                    metodofactura.mf_id AS mf_id
                    FROM 
                        facturas 
                    JOIN 
                        clientes ON facturas.clien_id = clientes.cliente_id 
                    JOIN 
                        usuarios ON clientes.user_id = usuarios.user_id 
                    JOIN 
                        detallefacturas ON facturas.fact_id = detallefacturas.fact_id
                    JOIN 
                        productos ON detallefacturas.prod_id = productos.prod_id  
                    JOIN 
                        metodofactura ON facturas.fact_id = metodofactura.fact_id
                    JOIN 
                        metodopago ON metodofactura.met_id = metodopago.met_id
                    WHERE 
                        $fact_id";
            
                $resultFactura = ejecutar($queryFactura);
            
                if ($resultFactura) {
                    // Almacenar resultados del bucle externo en un array
                    $facturasArray = [];
                    while ($rowFactura = $resultFactura->fetch_assoc()) {
                        $facturasArray[] = $rowFactura;
                    }
                    $facturaAnterior1 = null;

                    foreach ($facturasArray as $factura_id) {
                        if (empty($miArray) || !in_array($factura_id['factura_id'].'0', array_column($facturaAnterior1, 'factura_id'))) {
                            echo '<div class="Factura" style="border: 1px solid black; padding: 3px;">';
                                // Presentación de la información de la factura
                                // $facturaAnterior2 = null;

                                // foreach ($facturasArray as $rowFactura) {
                                    // Verificar si es una factura diferente a la anterior
                                    // if ($facturaAnterior2 === null || $facturaAnterior2['factura_id'] !== $rowFactura['factura_id']) {
                                        // Sección ID, FECHA Y TIPO DE FACTURA
                                        // echo "<h4> <div style= 'border-right: 1px solid black; padding: 3px; display: inline-block'> Factura: {$rowFactura['factura_id']} </div> <div style= 'border-right: 1px solid black; padding: 3px; display: inline-block'> Fecha: {$rowFactura['factura_fechaEmision']} </div> Tipo: {$rowFactura['factura_tipo']}</h4>";
                                        echo "<h4> <div style= 'border-right: 1px solid black; padding: 3px; display: inline-block'> Factura: {$factura_id['factura_id']} </div> <div style= 'border-right: 1px solid black; padding: 3px; display: inline-block'> Fecha: {$factura_id['factura_fechaEmision']} </div> Tipo: {$factura_id['factura_tipo']}</h4>";
                                    // }

                                    // Actualizar la factura anterior
                                    // $facturaAnterior2 = $rowFactura;

                                    // Resto del código...
                                // }
                                echo "<hr>";
                                // Sección TABLA PRODUCTOS
                                echo "<h4>PRODUCTOS</h4>";
                                echo "<table>";
                                echo "<tr><th>Producto</th><th>Descripción</th><th>Precio Unitario</th><th>Cantidad</th><th>Precio Parcial</th></tr>";
                                $detalleIdAnterior = null;
                                foreach ($facturasArray as $rowProducto) {
                                    if ($factura_id['factura_id'] == $rowProducto['factura_id']) {
                                        if ($detalleIdAnterior === null || $detalleIdAnterior !== $rowProducto['detalle_id']) {
                                            $precio_parcial = $rowProducto["producto_precio"] * $rowProducto["detalle_cantidad"];
                                            echo "<tr><td>{$rowProducto['producto_nombre']}</td><td>{$rowProducto['producto_descripcion']}</td><td>{$rowProducto['producto_precio']}</td><td>{$rowProducto['detalle_cantidad']}</td><td>$precio_parcial</td></tr>";
                                        }
                                        $detalleIdAnterior = $rowProducto['detalle_id'];
                                    }
                                }
                                echo "</table>";
                                echo "<hr>";
                                // Sección TOTAL
                                $ejemplo = $factura_id['factura_total']."0";
                                echo "<h4> Total Factura: {$ejemplo}</h4>";
                                echo "<hr>";
                                // Sección MEDIOS DE PAGO
                                echo "<h4>MEDIOS DE PAGO</h4>";
                                echo "<table>";
                                echo "<tr><th>Medio</th><th>Monto</th></tr>";
                                $mfIdAnterior = null;
                                foreach ($facturasArray as $rowFactura) {
                                    if ($factura_id['factura_id'] == $rowFactura['factura_id']) {
                                        if ($mfIdAnterior === null || $mfIdAnterior !== $rowFactura['mf_id']) {
                                            echo "<tr><td>{$rowFactura['pago_nombre']}</td><td>{$rowFactura['metodo_monto']}</td></tr>";
                                        }
                                        $mfIdAnterior = $rowFactura['mf_id'];
                                    }
                                }
                                echo "</table>";
                                echo "<hr>";
                                echo "<button type='button' style='margin: 7px;' disabled>IMPRIMIR</button><button type='button' style='margin: 7px;' disabled>ENVIAR</button>";
                            echo '</div>';
                            echo $factura_id['factura_id'];
                            echo '<br>';
                            $facturaAnterior1[] = (int)$factura_id['factura_id'];
                            $i=0;
                            echo $facturaAnterior1[$i];
                            echo $i;
                            $i++;
                        }
                    }


                } else {
                    echo "<br>Select de productos NO realizado con éxito<br>";
                }
                        
            } elseif (isset($_POST["Volver"])) {
                // Código para el botón "Volver"
                header("Location: ../facturas.php");
                exit();
            } else {
                // Código para otras situaciones
                echo "<br>Comando no válido<br>";
            }
            
?>
