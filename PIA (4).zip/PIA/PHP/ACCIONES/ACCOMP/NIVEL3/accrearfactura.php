<?php
            require '../../ACCIONES/FUNCIONES/conexion.php';

            $id = $_SESSION['id'];
            $data = $_POST;
            $factura = time();
            
            // Verificar directamente qué botón fue presionado en el formulario
            if (isset($_POST["botonPagar"])) {

                $cliente = $_POST['cliente'];
                $contador = $_POST['contador'];
                $fecha =$_POST['fecha'];
                $tipoDeTransaccion = $_POST['tipoDeTransaccion'];
                $totalFactura = 0;
                $precioProducto;
                $cantidadStock;
                
                $query = "INSERT INTO `facturas`(`fact_id`, `clien_id`, `tipo`, `fechaEmision`) VALUES ('$factura','$cliente','$tipoDeTransaccion','$fecha')";
                $result = ejecutar($query);
                if ($result) {
                    $_SESSION['idFact'] = $factura;
                    echo "Datos insertados a facturas<br>";
                } else {
                    echo "Datos NO insertados a facturas<br>";
                }

                if ($result) {
                    for ($i=0; $i < $contador; $i++) { 
                        $producto = $_POST['nuevoSelect_'.($i+1)];
                        $cantidad = $_POST['nuevoInput_'.($i+1)];
                        $query = "INSERT INTO `detallefacturas`(`fact_id`, `prod_id`, `cantidad`) VALUES ('$factura','$producto','$cantidad')";
                        $result = ejecutar($query);
                        if ($result) {
                            echo "Datos insertados a detalleFacturas<br>";
                        } else {
                            echo "Datos NO insertados a detalleFacturas<br>";
                        }
                        
                        $query = "SELECT * FROM `productos` WHERE prod_id = $producto";
                        $result = ejecutar($query);
                        if ($result) {
                            echo "Select de productos realizado con exito<br>";
                        } else {
                            echo "Select de productos NO realizado con exito<br>";
                        }
                        while ($row = $result->fetch_assoc()) {
                            $precioProducto = $row["precio"];
                            $cantidadStock = $row["cantidad_stock"];                            
                        }
                        $precioProducto = $precioProducto * $cantidad;
                        $totalFactura = $totalFactura + $precioProducto;
                        if ($tipoDeTransaccion === "Entrada") {
                            $cantidadStock = $cantidadStock + $cantidad;
                            $query = "UPDATE productos SET cantidad_stock = $cantidadStock WHERE prod_id = $producto";
                            $result = ejecutar($query);
                            if ($result) {
                                echo "Cantidad en productos actualizada con exito, fue una Entrada<br>";
                            } else {
                                echo "Cantidad en productos NO actualizada con exito, fue una Entrada<br>";
                            }
                        } elseif ($tipoDeTransaccion === "Salida") {
                            $cantidadStock = $cantidadStock - $cantidad;
                            $query = "UPDATE productos SET cantidad_stock = $cantidadStock WHERE prod_id = $producto";
                            $result = ejecutar($query);
                            if ($result) {
                                echo "Cantidad en productos actualizada con exito, fue una Salida<br>";
                            } else {
                                echo "Cantidad en productos NO actualizada con exito, fue una Salida<br>";
                            }
                        } else {
                            echo "Algo salió mal";
                        }
                        
                    }
                    
                    $query = "UPDATE facturas SET total = $totalFactura WHERE fact_id = $factura";
                    $result = ejecutar($query);
                    if ($result) {
                        echo "Total en facturas actualizado con exito<br>";
                        echo "<p>El Total es ".$totalFactura;
                        include 'Nivel4/divpagos.php';                       
                    } else {
                        echo "Total en facturas NO actualizado con exito<br>";
                    }

                } else {
                    echo "No se que pasó";
                }
                        
            } elseif (isset($_POST["botonEnviar"])) {
                $contadorPagos = $_POST['contadorPagos'];
                $botonEnviar = $_POST['botonEnviar'];
                $idFact = $_SESSION['idFact'];
                echo $idFact;
                for ($i=0; $i < $contadorPagos; $i++) { 
                    $metodo = $_POST['nuevoSelect2_'.($i+1)];
                    $monto = $_POST['nuevoInput2_'.($i+1)];
                    $query = "INSERT INTO `metodofactura`(`fact_id`, `met_id`, `monto`) VALUES ('$idFact','$metodo','$monto')";
                    $result = ejecutar($query);
                    if ($result) {
                        echo "<br>Datos ingresados correctamente a metodoFactura<br>";
                        $_SESSION['idFact'] = "";
                    } else {
                        echo "<br>Datos NO ingresados correctamente a metodoFactura<br>";
                        $_SESSION['idFact'] = "";
                    }
                    
                }
            } elseif (isset($_POST["Volver"])) {
                // Código para el botón "Volver"
                header("Location: ../menu.php");
                exit();
            } else {
                // Código para otras situaciones
                echo "Comando no válido";
            }
            
?>
