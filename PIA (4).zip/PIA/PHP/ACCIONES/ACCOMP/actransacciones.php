<?php
require '../ACCIONES/FUNCIONES/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtén los datos del formulario
    $prod = $_POST["input1"];
    $transaccion = $_POST["input2"];
    $cantidad = $_POST["input3"];
    $fecha = $_POST["input4"];
    if (isset($_POST["Enviar"])) {
        
        $query = "SELECT * FROM `productos` WHERE prod_id = $prod";
        $result = ejecutar($query);
        while ($row = $result ->fetch_assoc()) {
            $prod_id = $row["prod_id"];
            $cant = $row["cantidad_stock"];
        }
        $nuevacantidad;
        if ($transaccion == "Salida") {
            $nuevacantidad = $cant - $cantidad;
        } elseif ($transaccion == "Entrada") {
            $nuevacantidad = $cant + $cantidad;
        } else {
            echo "error";
        }
        if ($nuevacantidad < 0) {
            echo "No se puede realizar la transacción, no hay suficientes productos en el stock";
        } elseif ($nuevacantidad == 0) {
            echo "Los productos se acabaron, recargue para la proxima transacción";
        } else {
            $query = "INSERT INTO `transacciones`(`prod_id`, `tipo`, `cantidad`, `fecha`) VALUES ($prod,'$transaccion',$cantidad,'$fecha')";
            $result = ejecutar($query);
            if ($result === TRUE) {
                echo "Transacción insertada con exito";
                $query = "UPDATE `productos` SET `cantidad_stock`='$nuevacantidad' WHERE prod_id = $prod";
                $result = ejecutar($query);
            } else {
                echo "Problemas con la inserción";
            }
        }
        
        
    } else {
        //Previene de errores no previstos
        echo "Comando no válido";
    }
}




?>