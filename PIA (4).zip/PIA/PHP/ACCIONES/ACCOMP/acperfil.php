<?php
require '../ACCIONES/FUNCIONES/conexion.php';


$query = "SELECT * FROM `usuarios` WHERE user_id = $id";
$result = ejecutar($query);
while ($row = $result ->fetch_assoc()) {
    echo "<tr>";
    echo "<th>ID:" . "</th><td>" . $row["user_id"] . "</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<th>Nombre:" . "</th><td>" . $row["nombre"] . "</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<th>Correo:" . "</th><td>" . $row["correo"] . "</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<th>Celular:" . "</th><td>" . $row["telefono"] . "</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<th>Rol:" . "</th><td>" . $row["rol"] . "</td>";
    echo "</tr>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["EditarPerfil"])) {

        header("Location: ./Nivel3/actperfil.php");
        exit();

    } elseif (isset($_POST["CambiarContrasena"])) {
        header("Location: ./Nivel3/actcontrasena.php");
        exit();
    } else {
        //Previene de errores no previstos
        echo "Comando no válido";
    }
}




?>