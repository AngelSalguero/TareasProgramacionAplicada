<?php
require '../ACCIONES/FUNCIONES/conexion.php';


$id = $_GET['id'];
$query = "SELECT * FROM `usuarios` WHERE user_id = $id";
$result = ejecutar($query);
while ($row = $result ->fetch_assoc()) {
    echo "<div id='respuesta'>"."ID: " . $row["user_id"] . "<br>";
    echo "Nombre: " . $row["nombre"] . "<br>";
    echo "Correo: " . $row["correo"] . "<br>";
    echo "Celular: " . $row["telefono"] . "<br>";
    echo "Rol: " . $row["rol"] . "<br>";
    echo "<hr></div>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_GET['id'];
    $query = "SELECT * FROM `usuarios` WHERE user_id = $id";
    $result = ejecutar($query);
    while ($row = $result ->fetch_assoc()) {
    echo "<div id='respuesta'>"."ID: " . $row["user_id"] . "<br>";
    echo "Nombre: " . $row["nombre"] . "<br>";
    echo "Correo: " . $row["correo"] . "<br>";
    echo "Celular: " . $row["telefono"] . "<br>";
    echo "Rol: " . $row["rol"] . "<br>";
    echo "<hr></div>";
    }
    if (isset($_POST["EditarPerfil"])) {
        echo "<script>window.location.href = './Nivel3/actperfil.php?id=$id';</script>";
        exit();
    } elseif (isset($_POST["CambiarContrasena"])) {
        echo "<script>window.location.href = './Nivel3/actperfil.php?id=$id';</script>";
        exit();
    } else {
        //Previene de errores no previstos
        echo "Comando no válido";
    }
}




?>