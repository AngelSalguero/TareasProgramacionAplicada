<?php
 // Hace posible la ejecucion de las funciones, de tal manera que no tenga que ponerla en cada archivo
 require './ACCIONES/FUNCIONES/conexion.php';

// Verifica si se han enviado datos a través del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["Buscar"])) {

        // Obtén los datos del formulario
        $correo = $_POST["input3"];
        $contrasena = $_POST["input5"];

        if ($correo == 0) {
                //Previene del error de 0 ya existe
                echo "<h3 id='respuesta'> Cambie el correo </h3>";
        } elseif ($correo == "") {
                //Previene de un lugar vacio en el primary key
                echo "<h3 id='respuesta'> Agregue un correo </h3>";
        } else {
            $query = "SELECT * FROM `usuarios` WHERE correo = '$correo'";
            $result = ejecutar($query);
                //Verifica que el id no exista en la base de datos
                if ($result->num_rows == 0) {
                    echo "<h3 id='respuesta'> El correo $correo no se encuentra registrado </h3>";
                } else {
                    // Query SQL para realizar la inserción
                    $sql = "SELECT contrasena, user_id FROM `usuarios` WHERE correo = '$correo'";
                    try {
                        //Crea una variable result que es el resultado de la busqueda
                        $result = ejecutar($sql);
                        while ($row = $result ->fetch_assoc()) {
                            //Asigna la constreña de la BD a una variable en el codigo
                            $variable = $row["contrasena"];
                            $id_usuario = $row["user_id"];
                            session_start();
                            $_SESSION['id'] = $id_usuario;
                            if ($variable === $contrasena) {
                                header("Location: ./COMPONENTS/menu.php");
                                exit();
                            } else {
                                echo "<h3 id='respuesta'>Contraseña incorrecta </h3>";
                                echo "<hr>";
                            }
                        }
                        
                    } catch (mysqli_sql_exception $e) {
                        // Captura el error y muestra un mensaje personalizado
                        echo "<h3 id='respuesta'>Error en la consulta: </h3>" . $e->getMessage();
                    }
                }
                
                    
        }

    } else {
        
        //Previene de errores no previstos
        echo "<h3 id='respuesta'> Comando no valido </h3>";
    
    }

}


?>