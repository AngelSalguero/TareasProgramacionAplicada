<?php
 // Hace posible la ejecucion de las funciones, de tal manera que no tenga que ponerla en cada archivo
require './ACCIONES/FUNCIONES/conexion.php';

// Verifica si se han enviado datos a través del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["Insertar"])) {

        // Obtén los datos del formulario
        $nombre = $_POST["input2"];
        $correo = $_POST["input3"];
        $celular = $_POST["input4"];
        $contrasena = $_POST["input5"];
        $rol = $_POST["input6"];

        if ($correo == 0) {
                //Previene del error de 0 ya existe
                echo "<h3 id='respuesta'> Cambie el correo </h3>";
        } elseif ($correo == "") {
                //Previene de un lugar vacio en el primary key
                echo "<h3 id='respuesta'> Agregue un correo </h3>";
        } else {
            $query = "SELECT * FROM `usuarios` WHERE correo = '$correo'";
            $result = ejecutar($query);
                //Verifica que el id no exista en la base de datos
                if ($result->num_rows == 0) {
                    // Query SQL para realizar la inserción
                    $sql = "INSERT INTO `usuarios`(`nombre`, `correo`, `telefono`, `contrasena`, `rol`) VALUES ('$nombre','$correo','$celular','$contrasena','$rol')";
                    try {
                        //Crea una variable result que es el resultado de la insercion
                        $result = ejecutar($sql);
                        if ($result === TRUE) {
                            echo "<h3 id='respuesta'>Registro insertado con éxito.</h3>";
                        } else {
                            echo "<h3 id='respuesta'>Error al insertar el registro: </h3>" . $connection->error;
                            echo "<hr>";
                        }
                    } catch (mysqli_sql_exception $e) {
                        // Captura el error y muestra un mensaje personalizado
                        echo "<h3 id='respuesta'>Error en la consulta: </h3>" . $e->getMessage();
                    }
                } else {
                    echo "<h3 id='respuesta' >El correo $correo ya se encuentra registrado</h3>";
                }
                
                    
        }

    } else {
        
        //Previene de errores no previstos
        echo "Comando no valido";
    
    }

}


?>