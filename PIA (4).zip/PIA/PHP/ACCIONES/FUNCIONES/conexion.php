<?php

if (!function_exists('conectar')) {
    function conectar(){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "proyecto";
    
        // Crear una conexión a la base de datos
        $conn = new mysqli($servername, $username, $password, $database);
    
        // Verificar la conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }
        return $conn;
        echo ("Conexion exitosa");
    }
}

if (!function_exists('desconectar')) {
    function desconectar($conn){
        //Desconecta a la base de datos
        mysqli_close($conn);
    }
}

if (!function_exists('ejecutar')) {
    function ejecutar($query){

        $connection = conectar();    
        $result = $connection -> query($query);
        return $result;
        desconectar($connection);

    }
}


?>