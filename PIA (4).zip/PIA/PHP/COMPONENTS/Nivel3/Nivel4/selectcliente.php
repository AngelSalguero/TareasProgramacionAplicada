<?php
                require '../../ACCIONES/FUNCIONES/conexion.php';
                session_start();
                $id = $_SESSION['id'];
                $query = "SELECT * FROM `clientes` WHERE user_id = $id";
                $result = ejecutar($query);
                $cliente_id;
                $nombre;
                echo '<select name="cliente" id="cliente">';
                while ($row = $result->fetch_assoc()) {
                    $cliente_id = $row["cliente_id"];
                    $nombre = $row["nombre"];
                    echo '<option value="' . $cliente_id . '">' . $nombre . '</option>';
                }
                echo '</select>';
?>