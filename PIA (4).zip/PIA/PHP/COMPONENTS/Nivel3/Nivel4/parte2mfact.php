<?php

    require '../../ACCIONES/FUNCIONES/conexion.php';
    $id = $_SESSION['id'];

    if (isset($_POST["Productos"])) {

        $factura = $_POST["factura"];

        $query = "SELECT * FROM `factura` WHERE fact_id = $factura";
        $result = ejecutar($query);

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $cliente_id = $row["fact_id"];
                $cliente_nombre = $row["nombre"];
                $cliente_apellido = $row["apellido"];
                $cliente_correo = $row["correo"];
                $cliente_telefono = $row["telefono"];

                echo "<table>";

                echo "<tr>";
                echo "<th>Id</th>";
                echo "<th>Nombre</th>";
                echo "<th>Apellido</th>";
                echo "<th>Correo</th>";
                echo "<th>Teléfono</th>";
                echo "</tr>";

                echo "<tr>";
                echo "<td>". $cliente_id ."</td>";
                echo "<td>". $cliente_nombre ."</td>";
                echo "<td>". $cliente_apellido ."</td>";
                echo "<td>". $cliente_correo ."</td>";
                echo "<td>". $cliente_telefono ."</td>";
                echo "</tr>";

                echo "</table>";
            }
        } else {
                echo "<br>Select de productos NO realizado con exito<br>";
            }
    
        $query = "SELECT * FROM `facturas` WHERE clien_id = $cliente";
        $result = ejecutar($query);

        echo '<label for="factura">Seleccionar factura</label><br>';
        echo '<select name="factura" id="factura">';
        while ($row = $result->fetch_assoc()) {
            $fact_id = $row["fact_id"];
            $fecha = $row["fechaEmision"];
            $total = $row["total"];
            echo '<option value="' . $fact_id . '">' . $fact_id . '</option>';
        }
        echo '</select>';

        echo '<br>';

        echo '<button type="submit" name="Productos">Seleccionar Factura</button>';

    }
?>