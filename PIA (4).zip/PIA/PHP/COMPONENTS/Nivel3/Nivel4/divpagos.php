<br><br>


<div id="Pagos">
<label for="input4">Medios de pago</label><br>
<!-- Aquí pedir la cantidad de prodmedios de pago para crear el arrays y la cantidad de inputs -->
<table>
<tr id="labelPagos" for="contenedor3"></tr>
<tr id="contenedor2"></tr>
<tr id="contenedor3"></tr>
</table>
<button type="button" id="AgregarPago">Agregar Nuevo Medio de Pago</button><br>
<label for="contadorPagos">La cantidad de medios que va a agregar es: </label>
<br>
<input type="number" id="contadorPagos" name="contadorPagos" value=0></input>
</div>

<br><br>