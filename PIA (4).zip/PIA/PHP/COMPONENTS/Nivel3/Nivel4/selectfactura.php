<?php

    require '../../ACCIONES/FUNCIONES/conexion.php';
    $id = $_SESSION['id'];

    if (isset($_POST["Facturas"])) {

        $cliente = $_POST["cliente"];
    
        $query = "SELECT * FROM `facturas` WHERE clien_id = $cliente";
        $result = ejecutar($query);

        echo '<label for="factura">Seleccionar factura</label><br>';
        echo '<select name="factura" id="factura">';
        while ($row = $result->fetch_assoc()) {
            $fact_id = $row["fact_id"];
            $fecha = $row["fechaEmision"];
            $total = $row["total"];
            echo '<option value="facturas.fact_id = ' . $fact_id . '">' . $fact_id . '</option>';
        }
            echo '<option value="facturas.clien_id=' . $cliente . '">Traer todas</option>';
        echo '</select>';

        echo '<br>';

        echo '<button type="submit" name="MostrarFacturas" id="MostrarFacturas">Seleccionar Factura</button>';

    }
?>