<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEVEN</title>
    <link rel="stylesheet" type="text/css" href="../../../CSS/Nivel3/actperfil.css">
</head>
<body>

    <h1>ACTUALIZAR METODOS</h1>

    <form class="forms" action="actmetodos.php" method="post">
        
        <label class="labelActPerfil" for="input1">Id:</label>
        <input class="inputActPerfil" type="number" id="input1" name="input1" placeholder="Id Producto">
        <br><br>

        <label class="labelActPerfil" for="input2">Nombre:</label>
        <input class="inputActPerfil" type="text" id="input2" name="input2" placeholder="nombre(s)">
        <br><br>

        <input class="botonActPerfil" type="submit" name="Traer" value="mostrar">
        <input class="botonActPerfil" type="submit" name="Actualizar" value="actualizar">
        <input class="botonActPerfil" type="submit" name="Insertar" value="agregar">
        <input class="botonActPerfil" type="submit" name="Borrar" value="eliminar">
        <input class="botonActPerfil" type="submit" name="Volver" value="volver">

    </form>

</body>


<?php

    include '../../ACCIONES/ACCOMP/NIVEL3/acactmetodos.PHP';

?> 
</html>