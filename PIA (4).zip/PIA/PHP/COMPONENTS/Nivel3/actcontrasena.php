<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEVEN</title>
    <link rel="stylesheet" type="text/css" href="../../../CSS/Nivel3/actperfil.css">
</head>
<body>

    <h1>CAMBIO CONTRASEÑA</h1>

    <form class="forms" action="actcontrasena.php" method="post">

        <label class="labelActPerfil" for="input6">Nueva Contraseña:</label>
        <input class="inputActPerfil" type="text" id="input6" name="input6" placeholder="Contraseña">
        <br><br>

        <input class="botonActPerfil" type="submit" name="Actualizar" value="actualizar">
        <input class="botonActPerfil" type="submit" name="Volver" value="volver">

    </form>

</body>


<?php

    include '../../ACCIONES/ACCOMP/NIVEL3/acactcontrasena.PHP';

?> 
</html>