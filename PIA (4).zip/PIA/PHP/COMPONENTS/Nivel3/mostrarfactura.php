<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEVEN</title>
    <link rel="stylesheet" type="text/css" href="../../../CSS/Nivel3/mostrarfactura.css">
</head>

<body>
    <h1>Mostrar Factura</h1>

    <form action="mostrarfactura.php" method="post">

        <div id="clientes">
            <label for="cliente">Seleccionar cliente</label><br>
            <?php include 'Nivel4/selectcliente.php' ?>
        </div>

        <button type="submit" name="Facturas">Seleccionar Cliente</button>
        <button type="submit" name="Volver" >Volver</button>

        <br><br>
        <div id="factura">
            <?php include 'Nivel4/selectfactura.php'; ?>
        </div>

        <br><br>
        <div id="MostrarFacturas">
            <?php include '../../ACCIONES/ACCOMP/Nivel3/acmostrarfactura.php'; ?>
        </div>
    </form>

            <!-- <?php include '../../ACCIONES/ACCOMP/Nivel3/acmostrarfactura.php'; ?> -->


    </body>
</html>