<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEVEN</title>
    <link rel="stylesheet" type="text/css" href="../../../CSS/Nivel3/mostrarfactura.css">
</head>
<body>
    <h1>CREACION DE FACTURA</h1>

    <form action="crearfactura.php" method="post">

        <div id="clientes">
        <label for="cliente">Seleccionar cliente</label><br>
        <?php
            require '../../ACCIONES/FUNCIONES/conexion.php';
            session_start();
            $id = $_SESSION['id'];
            $query = "SELECT * FROM `clientes` WHERE user_id = $id";
            $result = ejecutar($query);
            $cliente_id;
            $nombre;
            echo '<select name="cliente" id="cliente">';
            while ($row = $result->fetch_assoc()) {
                $cliente_id = $row["cliente_id"];
                $nombre = $row["nombre"];
                echo '<option value="' . $cliente_id . '">' . $nombre . '</option>';
            }
            echo '</select>';
        ?>
        <input type="submit" name="AgregarCliente" value="Crear Cliente">
        </div>

        <br><br>
        
        <div id="productos">
        <!-- Aquí pedir la cantidad de productos para crear el arrays y la cantidad de inputs -->
        <table>
            <tr id="contenedor5"></tr>
            <tr id="contenedor"></tr>
            <tr id="contenedor4"></tr>
        </table>
        <button type="button" id="Agregar">Agregar Nuevo Producto</button><br>
        <label for="contador">La cantidad de productos que va a agregar es: </label>
        <br>
        <input type="number" id="contador" name="contador" value=0></input>
        </div>

        <br><br>
        
        <div id="fecha">
        <label for="fecha">Ingrese la fecha</label>
        <br>
        <input type="date" id="fecha" name="fecha" placeholder="Fecha">
        </div>

        <br><br>
        
        <div id="Transaccion">
        <label for="tipoDeTransaccion">Selecciones el tipo de transacción</label>
        <br>
        <select name="tipoDeTransaccion" id="tipoDeTransaccion">
            <option value="Entrada">Entrada</option>
            <option value="Salida">Salida</option>
        </select>
        </div>

        <br><br>

        <button type="submit" name="botonPagar">Pagar</button>

        <br><br>

        <?php include '../../ACCIONES/ACCOMP/Nivel3/accrearfactura.php'; ?>


        <br><br><br>
        <button type="submit" name="botonEnviar">Enviar Factura</button>
        <button type="submit" name="Volver" value="Volver">Volver</button>

    </form>


    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>

        // Inicializar el contador
        var contadorClics = 0;

        // Obtener referencia al botón y al párrafo del contador
        var miBoton = document.getElementById('Agregar');
        var contador = document.getElementById('contador');

        // Agregar un evento de clic al botón
        miBoton.addEventListener('click', function() {
            // Incrementar el contador
            contadorClics++;

            // Actualizar el contenido del párrafo del contador
            contador.value = contadorClics;
        });

        $("#Agregar").click(function() {
            var contenedor = document.getElementById('contenedor');
            var contenedor2 = document.getElementById('contenedor4');
            var contenedor3 = document.getElementById('contenedor5');

            // Crear un nuevo elemento select
            var nuevoTh1 = document.createElement('th');
            var nuevoTh2 = document.createElement('th');
            var nuevoTd = document.createElement('td');
            var nuevoSelect = document.createElement('select');
            var nuevoInput = document.createElement('input');
            var nuevoLabel = document.createElement('label');

            // Asignar un nombre e id al nuevo select basado en la marca de tiempo
            // var timestamp = new Date().getTime();
            // nuevoSelect.name = 'nuevoSelect_' + timestamp;
            // nuevoSelect.id = 'nuevoSelect_' + timestamp;

            // Obtener el valor actual del contador
            var contador = document.getElementById('contador').value;
            nuevoTh1.name = 'nuevoTh_' + contador;
            nuevoTh1.id = 'nuevoTh_' + contador;
            nuevoTh2.name = 'nuevoTh4_' + contador;
            nuevoTh2.id = 'nuevoTh4_' + contador;
            nuevoTd.name = 'nuevoTd5_' + contador;
            nuevoTd.id = 'nuevoTd5_' + contador;
            nuevoSelect.name = 'nuevoSelect_' + contador;
            nuevoSelect.id = 'nuevoSelect_' + contador;
            nuevoInput.name = 'nuevoInput_' + contador;
            nuevoInput.id = 'nuevoInput_' + contador;
            nuevoInput.placeholder = 'Producto' + contador;
            nuevoLabel.name = 'nuevoLabel';
            nuevoLabel.id = 'nuevoLabel';

            // Realizar una solicitud AJAX para obtener las opciones del servidor
            $.ajax({
                type: 'POST', // O 'GET' dependiendo de cómo esté configurado tu servidor PHP
                url: '../../ACCIONES/ACCOMP/Nivel3/opcionesproductos.php',
                data: { contador: contador }, // Incluir el contador en los datos
                success: function(response) {
                    // Agregar las opciones al nuevo select
                    // nuevoSelect.innerHTML = response;

                    // // Agregar el nuevo select al contenedor
                    contenedor.append(nuevoTh1);
                    nuevoTh1.append(nuevoSelect);
                        $("#nuevoSelect_" + contador).html(response);
                    contenedor2.append(nuevoTd);
                    nuevoTd.append(nuevoInput);
                    contenedor3.append(nuevoLabel);
                        $("#nuevoLabel").html("<p>Ingrese la cantidad por producto<p>");

                },
                error: function(error) {
                    console.error('Error al obtener opciones: ', error);
                }
            })
        });

        // Inicializar el contador
        var contadorClics2 = 0;

        // Obtener referencia al botón y al párrafo del contador
        var miBoton2 = document.getElementById('AgregarPago');
        var contador2 = document.getElementById('contadorPagos');

        // Agregar un evento de clic al botón
        miBoton2.addEventListener('click', function() {
            // Incrementar el contador
            contadorClics2++;

            // Actualizar el contenido del párrafo del contador
            contador2.value = contadorClics2;
        });
        
        $("#AgregarPago").click(function() {
            var contenedor = document.getElementById('contenedor2');
            var contenedor2 = document.getElementById('contenedor3');

            // Crear un nuevo elemento select
            var nuevoSelect = document.createElement('select');
            var nuevoInput2 = document.createElement('input');
            var nuevoTh1 = document.createElement('th');
            var nuevoTh2 = document.createElement('th');

            var contador = document.getElementById('contadorPagos').value;
            nuevoTh1.name = 'nuevoTh2_' + contador;
            nuevoTh1.id = 'nuevoTh2_' + contador;
            nuevoTh2.name = 'nuevoTh3_' + contador;
            nuevoTh2.id = 'nuevoTh3_' + contador;
            nuevoSelect.name = 'nuevoSelect2_' + contador;
            nuevoSelect.id = 'nuevoSelect2_' + contador;
            nuevoInput2.name = 'nuevoInput2_' + contador;
            nuevoInput2.id = 'nuevoInput2_' + contador;
            nuevoInput2.placeholder = 'Monto ' + contador;

            // Realizar una solicitud AJAX para obtener las opciones del servidor
            $.ajax({
                type: 'POST', // O 'GET' dependiendo de cómo esté configurado tu servidor PHP
                url: '../../ACCIONES/ACCOMP/Nivel3/opcionespagos.php',
                data: { contador: contador }, // Incluir el contador en los datos
                success: function(response) {
                    // Agregar las opciones al nuevo select
                    // nuevoSelect.innerHTML = response;

                    // // Agregar el nuevo select al contenedor
                    contenedor.append(nuevoTh1);
                    nuevoTh1.append(nuevoSelect);
                        $("#nuevoSelect2_" + contador).html(response);
                        $("#labelPagos").html("Ingrese el monto por medio de pago");
                    contenedor2.append(nuevoTh2);
                    nuevoTh2.append(nuevoInput2);
                },
                error: function(error) {
                    console.error('Error al obtener opciones: ', error);
                }
            })
        });

        function enviarDatos() {
            var inputs = document.getElementsByTagName('input');
            var datos = {};

            // Recorrer todos los inputs y agregar sus nombres y valores al objeto datos
            for (var i = 0; i < inputs.length; i++) {
                datos[inputs[i].name] = inputs[i].value;
            }

            // Enviar los datos al servidor usando AJAX
            $.ajax({
                type: 'POST',
                url: '../../ACCIONES/ACCOMP/Nivel3/accrearfactura.php',
                data: datos,
                success: function(response) {
                    console.log('Datos enviados correctamente.');
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('Error al enviar datos:', textStatus, errorThrown);
                }
            });
        }
        
    </script>
</body>
</html>
