<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./CSS/style.css">
    <title>Formulario</title>
</head>
<body>
    <nav><?php include './menu.php' ?></nav>
    <h1>TRANSACCIONES</h1>

    <form action="transacciones.php" method="post">

        <label for="input1">Seleccione el producto:</label>
        <?php   require '../ACCIONES/FUNCIONES/conexion.php';
                  $query = "SELECT * FROM `productos` WHERE user_id = $id";
                  $result = ejecutar($query);
                  $prod_id;
                  $nombre;
                  echo '<select name="input1" id="input1">';
                  while ($row = $result ->fetch_assoc()) {
                      $prod_id = $row["prod_id"];
                      $nombre = $row["nombre"];
                          echo '<option value="' . $prod_id . '">' . $nombre . '</option>';
                  }
                  echo '</select>';?>
        <br><br>

        <label for="input2">Tipo de transacción:</label>
        <select name="input2" id="input2">
            <option value="Entrada">Entrada</option>
            <option value="Salida">Salida</option>
        </select>
        <br><br>

        <label for="input3">Cantidad:</label>
        <input type="number" id="input3" name="input3" placeholder="cantidad">
        <br><br>

        <label for="input4">Fecha:</label>
        <input type="date" id="input4" name="input4" placeholder="Fecha">
        <br><br>

        <input type="submit" name="Enviar" value="Enviar">

    </form>

    <?php include '../ACCIONES/ACCOMP/actransacciones.php'?>
</body>
</html>