<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./CSS/style.css">
    <title>Formulario</title>
</head>
<body>
    <nav><?php include './menu.php' ?></nav>
    <h1>METODOS DE PAGO</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>Metodo</th>
        </tr>
        <?php     include '../ACCIONES/ACCOMP/acmetodos.php'; ?>
    </table>

    <form class="forms" action="metodos.php" method="post">

        <input class="botonesForms" type="submit" name="EditarMetodos" value="Gestionar metodos de pago">

    </form>

</body>

</html>