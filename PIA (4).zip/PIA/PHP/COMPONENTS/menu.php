<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEVEN</title>
    <link rel="stylesheet" type="text/css" href="../../CSS/menu.css">
</head>
<nav>
    <h1 id="h1Menu">MENU</h1>
    <form id="formMenu" action="menu.php" method="post">
        <input class="botonMenu" type="submit" name="Perfil" value="Perfil">
        <input class="botonMenu" type="submit" name="Producto" value="Productos">
        <input class="botonMenu" type="submit" name="Clientes" value="Clientes">
        <input class="botonMenu" type="submit" name="MetodosDePago" value="Metodos De Pago">
        <input class="botonMenu" type="submit" name="Transacciones" value="Transacciones">
        <input class="botonMenu" type="submit" name="Informes" value="Informes">
        <input class="botonMenu" type="submit" name="Facturas" value="Facturas">
        <input class="botonMenu" type="submit" name="CerrarSesion" value="Cerrar Sesion">
    </form>
    <?php

        include '../ACCIONES/ACCOMP/acmenu.PHP';

    ?>
</nav>
</html>