<!DOCTYPE html>
<html>
<body>
    <nav><?php include './menu.php' ?></nav>
    <h1>PRODUCTOS</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripcion</th>
            <th>Precio</th>
            <th>Stock</th>
        </tr>
        <?php include '../ACCIONES/ACCOMP/acproductos.php'; ?>
    </table>

    <form class="forms" action="productos.php" method="post">

        <input clase="botonesForms" type="submit" name="EditarProductos" value="Gestionar Productos">

    </form>

</body>

</html>