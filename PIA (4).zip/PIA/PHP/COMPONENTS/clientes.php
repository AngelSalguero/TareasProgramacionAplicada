<!DOCTYPE html>
<html>
<body>
    <nav><?php include './menu.php' ?></nav>
    <h1>CLIENTES</h1>

    <form class="forms" action="clientes.php" method="post">

        <input class="botonesForms" type="submit" name="EditarClientes" value="Gestionar Clientes">

    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Correo</th>
            <th>Telefono</th>
        </tr>
        <?php include '../ACCIONES/ACCOMP/acclientes.php'; ?>
    </table>

</body>

</html>