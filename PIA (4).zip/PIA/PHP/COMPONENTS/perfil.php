<!DOCTYPE html>
<html>
<body>
    <?php include './menu.php' ?>
    <h1>PERFIL DEL USUARIO</h1>

    <table>
        <?php include '../ACCIONES/ACCOMP/acperfil.php'; ?>
    </table>

    <form class="forms" action="perfil.php" method="post">

        <input class="botonesForms" type="submit" name="EditarPerfil" value="Gestionar Perfil">
        <input class="botonesForms" type="submit" name="CambiarContrasena" value="Cambiar Contraseña">

    </form>

</body>

</html>