<!DOCTYPE html>
<html>
<body>
    <?php include './menu.php' ?>
    <h1>FACTURAS</h1>

    <form class="forms" action="facturas.php" method="post">

        <input class="botonesForms" type="submit" name="MostrarFacturas" value="Mostrar Facturas">
        <input class="botonesForms" type="submit" name="AgregarFacturas" value="Añadir Factura">

    </form>

</body>


<?php

    include '../ACCIONES/ACCOMP/acfacturas.php';

?>
</html>