<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" type="text/css" href="../CSS/nav.css">
    <title>Enviar a diferentes páginas con PHP</title>
</head>
<nav>

    <header>
        <h1>HOME</h1>
        <form id="nav" action="nav.php" method="post">
            <!-- Otros campos del formulario aquí -->

            <input class="nav" type="submit" name="boton1" value="ingresar">
            <input class="nav" type="submit" name="boton2" value="Registrarse">
            <input class="nav" type="submit" name="boton3" value="HOME">
        </form>
    </header>
</nav>

    <?php
        if (isset($_POST['boton1'])) {
            // El botón 1 fue presionado
            header("Location: login.php");
            exit();
        } elseif (isset($_POST['boton2'])) {
            // El botón 2 fue presionado
            header("Location: ./registro.php");
            exit();
        } elseif (isset($_POST['boton3'])) {
            // El botón 2 fue presionado
            header("Location: ../index.php");
            exit();
        } else {
            // Manejar otra lógica si es necesario
        }
    ?>