<!DOCTYPE html>
<html>
<head>
    <title>Formulario</title>
</head>
<body>
    <?php include 'nav.php' ?>

    <h1 id="REGISTRO">REGISTRO USUARIOS</h1>

    <form id="formRegistro" action="registro.php" method="post">

        <label for="input2">nombre:</label>
        <input type="text" id="input2" name="input2" placeholder="nombre(s)">
        <br><br>

        <label for="input3">correo:</label>
        <input type="text" id="input3" name="input3" placeholder="correo">
        <br><br>

        <label for="input4">celular:</label>
        <input type="text" id="input4" name="input4" placeholder="celular">
        <br><br>

        <label for="input5">contraseña:</label>
        <input type="text" id="input5" name="input5" placeholder="contraseña">
        <br><br>

        <label for="input6">rol:</label>
        <input type="text" id="input6" name="input6" placeholder="Vendedor/Dueño">
        <br><br>

        <input type="submit" name="Insertar" value="Enviar">

    </form>

</body>

<?php

    include './ACCIONES/registro.PHP';

?> 
</html>