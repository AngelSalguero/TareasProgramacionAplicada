<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" type="text/css" href="CSS/index.css">
    <title>Enviar a diferentes páginas con PHP</title>
</head>
<body>

    <header>
    <h1>HOME</h1>
        <form action="procesar.php" method="post">
            <!-- Otros campos del formulario aquí -->

            <input type="submit" name="boton1" value="ingresar">
            <input type="submit" name="boton2" value="Registrarse">
            <input type="submit" name="boton3" value="HOME">
        </form>
    </header>
</body>
</html>