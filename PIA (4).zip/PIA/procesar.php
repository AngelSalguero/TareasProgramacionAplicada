<?php
if (isset($_POST['boton1'])) {
    // El botón 1 fue presionado
    header("Location: ./PHP/login.php");
    exit();
} elseif (isset($_POST['boton2'])) {
    // El botón 2 fue presionado
    header("Location: ./PHP/registro.php");
    exit();
} elseif (isset($_POST['boton3'])) {
    // El botón 2 fue presionado
    header("Location: index.php");
    exit();
} else {
    // Manejar otra lógica si es necesario
}
?>